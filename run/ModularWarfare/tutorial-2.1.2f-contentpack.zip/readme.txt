This pack is the tutorial pack. 
This pack must install with prototype pack.

This pack have some simple pbr texture for example.
The animation`s blend files are in the blend folder.

The model are made by TastyTony.(no texture)(link in license file)
The model are remade by SIZStan.(Discord SIZ_Stan#0662)